// =============================================================================
// FILE: lib/features/admin/pt_dashboard/presentation/screens/trainer_schedule_screen.dart
//
// ROLE:
//   - Admin/Owner: trainerId = 0 → BLoC loads slots for ALL trainers.
//     Each slot card shows "By <TrainerName>" badge.
//     "Add Slot" dialog has a trainer picker.
//   - Trainer: trainerId != 0 → BLoC loads only own slots.
//
// DEPENDS ON:
//   AvailabilityBloc (injected externally via BlocProvider — no service here)
// =============================================================================

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/theme/theme_cubit.dart';
import '../../../../admin/trainers/data/models/admin_trainer_card_model.dart';
import '../../domain/entities/availability_entity.dart';
import '../bloc/availability/availability_bloc.dart';

const _weekdays = [
  'Monday', 'Tuesday', 'Wednesday',
  'Thursday', 'Friday', 'Saturday', 'Sunday',
];

class TrainerScheduleScreen extends StatefulWidget {
  final int  branchId;
  /// 0 = admin/owner (all-trainers mode)
  final int  trainerId;
  final bool isAdmin;
  final List<AdminTrainerCardModel> trainers;

  const TrainerScheduleScreen({
    super.key,
    required this.branchId,
    required this.trainerId,
    required this.isAdmin,
    required this.trainers,
  });

  @override
  State<TrainerScheduleScreen> createState() =>
      _TrainerScheduleScreenState();
}

class _TrainerScheduleScreenState extends State<TrainerScheduleScreen> {
  late final AvailabilityBloc _bloc;

  @override
  void initState() {
    super.initState();
    _bloc = context.read<AvailabilityBloc>();
    _load();
  }

  void _load() {
    _bloc.add(AvailabilitySlotsLoadRequested(
      trainerId: widget.isAdmin ? null : widget.trainerId,
      branchId:  widget.branchId,
    ));
  }

  String _trainerName(int trainerId) {
    try {
      return widget.trainers
          .firstWhere((t) => t.trainerId == trainerId)
          .fullName;
    } catch (_) {
      return 'Trainer #$trainerId';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tokens = context.read<ThemeCubit>().state.tokens;

    return BlocConsumer<AvailabilityBloc, AvailabilityState>(
      listener: (ctx, state) {
        if (state is AvailabilityMutationSuccess) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message)),
          );
        }
        if (state is AvailabilityError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: tokens.colors.error,
            ),
          );
        }
      },
      builder: (ctx, state) {
        return Scaffold(
          backgroundColor: tokens.colors.background,
          appBar: AppBar(
            title: Text(
              widget.isAdmin ? 'All Schedules' : 'My Availability',
              style: TextStyle(color: tokens.colors.label),
            ),
            backgroundColor: tokens.colors.surface,
            elevation: 0,
            actions: [
              IconButton(
                icon: Icon(Icons.add, color: tokens.colors.primary),
                onPressed: () => _showAddDialog(context, tokens),
              ),
            ],
          ),
          body: _buildBody(state, tokens),
        );
      },
    );
  }

  Widget _buildBody(AvailabilityState state, dynamic tokens) {
    if (state is AvailabilityLoading || state is AvailabilityMutating) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state is AvailabilityError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(state.message),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: _load, child: const Text('Retry')),
          ],
        ),
      );
    }

    final slots = state is AvailabilityLoaded
        ? state.slots
        : <AvailabilityEntity>[];

    if (slots.isEmpty) {
      return const Center(child: Text('No availability slots found.'));
    }

    // Group slots by weekday
    final Map<int, List<AvailabilityEntity>> grouped = {};
    for (final slot in slots) {
      grouped.putIfAbsent(slot.weekday, () => []).add(slot);
    }

    final sortedWeekdays = grouped.keys.toList()..sort();

    return RefreshIndicator(
      onRefresh: () async => _load(),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: sortedWeekdays.length,
        itemBuilder: (_, i) {
          final day = sortedWeekdays[i];
          final daySlots = grouped[day]!;
          final dayName = day >= 1 && day <= 7
              ? _weekdays[day - 1]
              : 'Day $day';

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 8, top: 4),
                child: Text(
                  dayName,
                  style: TextStyle(
                    color: tokens.colors.label,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
              ...daySlots.map((slot) => _SlotCard(
                slot:        slot,
                trainerName: _trainerName(slot.trainerId),
                showBadge:   widget.isAdmin,
                onDelete:    () {
                  _bloc.add(AvailabilitySlotDeleteRequested(
                      slot.availabilityId));
                },
              )),
              const SizedBox(height: 8),
            ],
          );
        },
      ),
    );
  }

  void _showAddDialog(BuildContext context, dynamic tokens) {
    showDialog(
      context: context,
      builder: (_) => _AddSlotDialog(
        isAdmin:  widget.isAdmin,
        trainers: widget.trainers,
        defaultTrainerId: widget.trainerId,
        onSubmit: ({
          required int trainerId,
          required int weekday,
          required String startTime,
          required String endTime,
          required bool recurring,
        }) {
          _bloc.add(AvailabilitySlotCreateRequested(
            trainerId: trainerId,
            branchId:  widget.branchId,
            weekday:   weekday,
            startTime: startTime,
            endTime:   endTime,
            recurring: recurring,
          ));
          Navigator.pop(context);
        },
      ),
    );
  }
}

// ── Slot card ─────────────────────────────────────────────────────────────────

class _SlotCard extends StatelessWidget {
  final AvailabilityEntity slot;
  final String trainerName;
  final bool showBadge;
  final VoidCallback onDelete;

  const _SlotCard({
    required this.slot,
    required this.trainerName,
    required this.showBadge,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final tokens = context.read<ThemeCubit>().state.tokens;

    return Card(
      color: tokens.colors.surface,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(tokens.card.radius),
      ),
      child: ListTile(
        leading: Icon(Icons.schedule, color: tokens.colors.primary),
        title: Text(
          '${slot.startTime} – ${slot.endTime}',
          style: TextStyle(color: tokens.colors.label, fontWeight: FontWeight.w500),
        ),
        subtitle: showBadge
            ? Text(
          'By $trainerName',
          style: TextStyle(color: tokens.colors.primary, fontSize: 12),
        )
            : Text(
          slot.isRecurring ? 'Recurring' : 'One-time',
          style: TextStyle(color: tokens.colors.muted, fontSize: 12),
        ),
        trailing: IconButton(
          icon: Icon(Icons.delete_outline, color: tokens.colors.danger),
          onPressed: () => showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('Delete Slot'),
              content: Text(
                  'Remove ${slot.startTime}–${slot.endTime} slot?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () {
                    onDelete();
                    Navigator.pop(context);
                  },
                  child: const Text('Delete',
                      style: TextStyle(color: Colors.red)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Add slot dialog ───────────────────────────────────────────────────────────

class _AddSlotDialog extends StatefulWidget {
  final bool isAdmin;
  final List<AdminTrainerCardModel> trainers;
  final int defaultTrainerId;
  final void Function({
  required int trainerId,
  required int weekday,
  required String startTime,
  required String endTime,
  required bool recurring,
  }) onSubmit;

  const _AddSlotDialog({
    required this.isAdmin,
    required this.trainers,
    required this.defaultTrainerId,
    required this.onSubmit,
  });

  @override
  State<_AddSlotDialog> createState() => _AddSlotDialogState();
}

class _AddSlotDialogState extends State<_AddSlotDialog> {
  int? _selectedTrainerId;
  int _selectedWeekday = 1;
  String _startTime = '09:00';
  String _endTime   = '10:00';
  bool _recurring = true;

  @override
  void initState() {
    super.initState();
    _selectedTrainerId =
    widget.defaultTrainerId != 0 ? widget.defaultTrainerId : null;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add Availability Slot'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (widget.isAdmin && widget.trainers.isNotEmpty)
              DropdownButtonFormField<int>(
                value: _selectedTrainerId,
                hint: const Text('Assign to Trainer'),
                items: widget.trainers.map((t) {
                  return DropdownMenuItem(
                    value: t.trainerId,
                    child: Text(t.fullName),
                  );
                }).toList(),
                onChanged: (v) =>
                    setState(() => _selectedTrainerId = v),
              ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _selectedWeekday,
              decoration:
              const InputDecoration(labelText: 'Day of Week'),
              items: List.generate(7, (i) {
                return DropdownMenuItem(
                  value: i + 1,
                  child: Text(_weekdays[i]),
                );
              }),
              onChanged: (v) =>
                  setState(() => _selectedWeekday = v ?? 1),
            ),
            const SizedBox(height: 12),
            _TimePicker(
              label:   'Start Time',
              initial: _startTime,
              onChange: (v) => setState(() => _startTime = v),
            ),
            const SizedBox(height: 8),
            _TimePicker(
              label:   'End Time',
              initial: _endTime,
              onChange: (v) => setState(() => _endTime = v),
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              title: const Text('Recurring (weekly)'),
              value: _recurring,
              onChanged: (v) => setState(() => _recurring = v),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            final trainerId =
                _selectedTrainerId ?? widget.defaultTrainerId;
            if (trainerId == 0) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('Please select a trainer.')),
              );
              return;
            }
            widget.onSubmit(
              trainerId: trainerId,
              weekday:   _selectedWeekday,
              startTime: _startTime,
              endTime:   _endTime,
              recurring: _recurring,
            );
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}

class _TimePicker extends StatelessWidget {
  final String label;
  final String initial;
  final void Function(String) onChange;

  const _TimePicker({
    required this.label,
    required this.initial,
    required this.onChange,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        final parts = initial.split(':');
        final picked = await showTimePicker(
          context: context,
          initialTime: TimeOfDay(
            hour:   int.tryParse(parts[0]) ?? 9,
            minute: int.tryParse(parts[1]) ?? 0,
          ),
        );
        if (picked != null) {
          onChange(
            '${picked.hour.toString().padLeft(2, '0')}:'
                '${picked.minute.toString().padLeft(2, '0')}',
          );
        }
      },
      child: InputDecorator(
        decoration: InputDecoration(
          labelText: label,
          suffixIcon: const Icon(Icons.access_time),
        ),
        child: Text(initial),
      ),
    );
  }
}