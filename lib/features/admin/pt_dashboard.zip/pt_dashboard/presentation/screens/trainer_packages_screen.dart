// =============================================================================
// FILE: lib/features/admin/pt_dashboard/presentation/screens/trainer_packages_screen.dart
//
// ROLE:
//   - Admin/Owner mode: trainerId param is 0 → BLoC fetches ALL packages.
//     Each card shows a "By <TrainerName>" badge resolved from the trainers list.
//     The "New Package" dialog has a trainer picker so admin can assign.
//   - Trainer mode: trainerId != 0 → BLoC fetches only own packages.
//     No trainer picker shown.
//
// DEPENDS ON:
//   PtPackageBloc (injected externally — no service construction here)
// =============================================================================

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../core/theme/theme_cubit.dart';
import '../../../../admin/trainers/data/models/admin_trainer_card_model.dart';
import '../../domain/entities/pt_package_entity.dart';
import '../bloc/packages/pt_package_bloc.dart';
import '../bloc/packages/pt_package_state.dart';
import '../bloc/packages/pt_package_bloc.dart' hide PtPackageBloc, PtPackageState, PtPackageError, PtPackageLoading, PtPackageMutating, PtPackageLoaded;

class TrainerPackagesScreen extends StatefulWidget {
  final int  tenantId;
  final int  branchId;
  /// 0 = admin/owner (all-trainers mode), non-zero = that trainer only
  final int  trainerId;
  final bool isAdmin;
  final List<AdminTrainerCardModel> trainers;

  const TrainerPackagesScreen({
    super.key,
    required this.tenantId,
    required this.branchId,
    required this.trainerId,
    required this.isAdmin,
    required this.trainers,
  });

  @override
  State<TrainerPackagesScreen> createState() => _TrainerPackagesScreenState();
}

class _TrainerPackagesScreenState extends State<TrainerPackagesScreen> {
  late final PtPackageBloc _bloc;

  @override
  void initState() {
    super.initState();
    _bloc = context.read<PtPackageBloc>();
    _load();
  }

  void _load() {
    _bloc.add(PtPackagesLoadRequested(
      trainerId: widget.isAdmin ? null : widget.trainerId,
      tenantId:  widget.tenantId,
      branchId:  widget.branchId,
    ));
  }

  String _trainerName(int trainerId) {
    try {
      return widget.trainers
          .firstWhere((t) => t.trainerId == trainerId)
          .fullName;
    } catch (_) {
      return 'Trainer #$trainerId';
    }
  }

  @override
  Widget build(BuildContext context) {
    final tokens = context.read<ThemeCubit>().state.tokens;

    return BlocConsumer<PtPackageBloc, PtPackageState>(
      listener: (ctx, state) {
        if (state is PtPackageMutationSuccess) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.message)),
          );
        }
        if (state is PtPackageError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: tokens.colors.error,
            ),
          );
        }
      },
      builder: (ctx, state) {
        return Scaffold(
          backgroundColor: tokens.colors.background,
          appBar: AppBar(
            title: Text(
              widget.isAdmin ? 'All Packages' : 'My Packages',
              style: TextStyle(color: tokens.colors.label),
            ),
            backgroundColor: tokens.colors.surface,
            elevation: 0,
            actions: [
              IconButton(
                icon: Icon(Icons.add, color: tokens.colors.primary),
                onPressed: () => _showCreateDialog(context, tokens),
              ),
            ],
          ),
          body: _buildBody(state, tokens),
        );
      },
    );
  }

  Widget _buildBody(PtPackageState state, dynamic tokens) {
    if (state is PtPackageLoading || state is PtPackageMutating) {
      return const Center(child: CircularProgressIndicator());
    }

    if (state is PtPackageError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(state.message),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: _load, child: const Text('Retry')),
          ],
        ),
      );
    }

    final packages = state is PtPackageLoaded ? state.packages : <PtPackageEntity>[];

    if (packages.isEmpty) {
      return const Center(child: Text('No packages found.'));
    }

    return RefreshIndicator(
      onRefresh: () async => _load(),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: packages.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (_, i) => _PackageCard(
          package:     packages[i] as PtPackageEntity,
          trainerName: _trainerName(
            (packages[i] as PtPackageEntity).trainerId,
      ),
          showBadge:   widget.isAdmin,
          onEdit:      (pkg) => _showEditDialog(context, pkg, tokens),
          onDeactivate:(pkg) => _confirmDeactivate(context, pkg),
        ),
      ),
    );
  }

  // ── Dialogs ───────────────────────────────────────────────────────────────

  void _showCreateDialog(BuildContext context, dynamic tokens) {
    showDialog(
      context: context,
      builder: (_) => _PackageFormDialog(
        isAdmin:   widget.isAdmin,
        trainers:  widget.trainers,
        defaultTrainerId: widget.trainerId,
        onSubmit: (trainerId, body) {
          _bloc.add(PtPackageCreateRequested(
            trainerId: trainerId,
            tenantId:  widget.tenantId,
            branchId:  widget.branchId,
            body:      body,
          ));
          Navigator.pop(context);
        },
      ),
    );
  }

  void _showEditDialog(
      BuildContext context,
      PtPackageEntity pkg,
      dynamic tokens,
      ) {
    showDialog(
      context: context,
      builder: (_) => _PackageFormDialog(
        isAdmin:   widget.isAdmin,
        trainers:  widget.trainers,
        defaultTrainerId: pkg.trainerId,
        initialPackage: pkg,
        onSubmit: (_, body) {
          _bloc.add(PtPackageUpdateRequested(
            packageId: pkg.id,
            body:      body,
          ));
          Navigator.pop(context);
        },
      ),
    );
  }

  void _confirmDeactivate(BuildContext context, PtPackageEntity pkg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Deactivate Package'),
        content: Text('Deactivate "${pkg.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              _bloc.add(PtPackageDeactivateRequested(pkg.id));
              Navigator.pop(context);
            },
            child: const Text('Deactivate',
                style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

// ── Package card ──────────────────────────────────────────────────────────────

class _PackageCard extends StatelessWidget {
  final PtPackageEntity package;
  final String trainerName;
  final bool showBadge;
  final void Function(PtPackageEntity) onEdit;
  final void Function(PtPackageEntity) onDeactivate;

  const _PackageCard({
    required this.package,
    required this.trainerName,
    required this.showBadge,
    required this.onEdit,
    required this.onDeactivate,
  });

  @override
  Widget build(BuildContext context) {
    final tokens = context.read<ThemeCubit>().state.tokens;

    return Card(
      color: tokens.colors.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(tokens.card.radius),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    package.name,
                    style: TextStyle(
                      color: tokens.colors.label,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                if (!package.isActive)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: tokens.colors.muted.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'Inactive',
                      style: TextStyle(color: tokens.colors.muted, fontSize: 11),
                    ),
                  ),
              ],
            ),
            if (showBadge) ...[
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: tokens.colors.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'By $trainerName',
                  style: TextStyle(
                    color: tokens.colors.primary,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 8),
            _infoRow(tokens, '${package.numberOfSessions} services',
                Icons.fitness_center),
            _infoRow(tokens,
                '${package.minDaysPerWeek}–${package.maxDaysPerWeek} days/week',
                Icons.calendar_today),
            _infoRow(tokens, '${package.sessionDurationMinutes} min/session',
                Icons.timer),
            _infoRow(tokens,
                package.salePrice != null
                    ? '\$${package.salePrice!.toStringAsFixed(2)} (was \$${package.price.toStringAsFixed(2)})'
                    : '\$${package.price.toStringAsFixed(2)}',
                Icons.attach_money),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () => onEdit(package),
                  icon: const Icon(Icons.edit, size: 16),
                  label: const Text('Edit'),
                ),
                const SizedBox(width: 4),
                TextButton.icon(
                  onPressed: () => onDeactivate(package),
                  icon: Icon(Icons.delete_outline,
                      size: 16, color: tokens.colors.danger),
                  label: Text('Deactivate',
                      style: TextStyle(color: tokens.colors.danger)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(dynamic tokens, String label, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(icon, size: 14, color: tokens.colors.muted),   // ← was tokens.muted
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: tokens.colors.body, fontSize: 13)), // ← was tokens.body
        ],
      ),
    );
  }
  }


// ── Package form dialog ───────────────────────────────────────────────────────

class _PackageFormDialog extends StatefulWidget {
  final bool isAdmin;
  final List<AdminTrainerCardModel> trainers;
  final int defaultTrainerId;
  final PtPackageEntity? initialPackage;
  final void Function(int trainerId, Map<String, dynamic> body) onSubmit;

  const _PackageFormDialog({
    required this.isAdmin,
    required this.trainers,
    required this.defaultTrainerId,
    required this.onSubmit,
    this.initialPackage,
  });

  @override
  State<_PackageFormDialog> createState() => _PackageFormDialogState();
}

class _PackageFormDialogState extends State<_PackageFormDialog> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _name;
  late final TextEditingController _sessions;
  late final TextEditingController _duration;
  late final TextEditingController _minDays;
  late final TextEditingController _maxDays;
  late final TextEditingController _price;
  late final TextEditingController _salePrice;

  int? _selectedTrainerId;

  @override
  void initState() {
    super.initState();
    final p = widget.initialPackage;
    _name     = TextEditingController(text: p?.name ?? '');
    _sessions = TextEditingController(
        text: p != null ? '${p.numberOfSessions}' : '');
    _duration = TextEditingController(
        text: p != null ? '${p.sessionDurationMinutes}' : '60');
    _minDays  = TextEditingController(
        text: p != null ? '${p.minDaysPerWeek}' : '1');
    _maxDays  = TextEditingController(
        text: p != null ? '${p.maxDaysPerWeek}' : '3');
    _price    = TextEditingController(
        text: p != null ? '${p.price}' : '');
    _salePrice= TextEditingController(
        text: p?.salePrice != null ? '${p!.salePrice}' : '');
    _selectedTrainerId =
    widget.defaultTrainerId != 0 ? widget.defaultTrainerId : null;
  }

  @override
  void dispose() {
    _name.dispose();
    _sessions.dispose();
    _duration.dispose();
    _minDays.dispose();
    _maxDays.dispose();
    _price.dispose();
    _salePrice.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.initialPackage == null
          ? 'New Package'
          : 'Edit Package'),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Trainer picker — only shown in admin/owner mode
              if (widget.isAdmin && widget.trainers.isNotEmpty) ...[
                DropdownButtonFormField<int>(
                  value: _selectedTrainerId,
                  hint: const Text('Assign to Trainer'),
                  items: widget.trainers.map((t) {
                    return DropdownMenuItem(
                      value: t.trainerId,
                      child: Text(t.fullName),
                    );
                  }).toList(),
                  onChanged: (v) =>
                      setState(() => _selectedTrainerId = v),
                  validator: (v) =>
                  v == null ? 'Please select a trainer' : null,
                ),
                const SizedBox(height: 12),
              ],
              _field(_name, 'Package Name',
                  validator: (v) =>
                  v == null || v.isEmpty ? 'Required' : null),
              _field(_sessions, 'Number of Sessions',
                  keyboardType: TextInputType.number,
                  validator: (v) =>
                  int.tryParse(v ?? '') == null ? 'Enter a number' : null),
              _field(_duration, 'Session Duration (min)',
                  keyboardType: TextInputType.number,
                  validator: (v) =>
                  int.tryParse(v ?? '') == null ? 'Enter a number' : null),
              _field(_minDays, 'Min Days/Week',
                  keyboardType: TextInputType.number,
                  validator: (v) =>
                  int.tryParse(v ?? '') == null ? 'Enter a number' : null),
              _field(_maxDays, 'Max Days/Week',
                  keyboardType: TextInputType.number,
                  validator: (v) =>
                  int.tryParse(v ?? '') == null ? 'Enter a number' : null),
              _field(_price, 'Price',
                  keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
                  validator: (v) =>
                  double.tryParse(v ?? '') == null ? 'Enter a price' : null),
              _field(_salePrice, 'Sale Price (optional)',
                  keyboardType:
                  const TextInputType.numberWithOptions(decimal: true)),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _submit,
          child: const Text('Save'),
        ),
      ],
    );
  }

  Widget _field(
      TextEditingController ctrl,
      String label, {
        TextInputType? keyboardType,
        String? Function(String?)? validator,
      }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        controller:   ctrl,
        keyboardType: keyboardType,
        decoration:   InputDecoration(labelText: label),
        validator:    validator,
      ),
    );
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final trainerId = _selectedTrainerId ?? widget.defaultTrainerId;
    if (trainerId == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a trainer.')),
      );
      return;
    }

    final body = {
      'name':                   _name.text.trim(),
      'numberOfSessions':       int.parse(_sessions.text.trim()),
      'sessionDurationMinutes': int.parse(_duration.text.trim()),
      'minDaysPerWeek':         int.parse(_minDays.text.trim()),
      'maxDaysPerWeek':         int.parse(_maxDays.text.trim()),
      'price':                  double.parse(_price.text.trim()),
      if (_salePrice.text.isNotEmpty)
        'salePrice': double.parse(_salePrice.text.trim()),
    };

    widget.onSubmit(trainerId, body);
  }
}